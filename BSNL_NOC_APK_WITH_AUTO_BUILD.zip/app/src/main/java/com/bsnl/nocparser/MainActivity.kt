
package com.bsnl.nocparser
import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.google.android.material.tabs.TabLayout

class MainActivity: AppCompatActivity(){
 lateinit var db: AppDatabase
 lateinit var txAdapter: TxAdapter
 lateinit var btsAdapter: BtsAdapter

 override fun onCreate(savedInstanceState: Bundle?){
  super.onCreate(savedInstanceState)
  setContentView(R.layout.activity_main)
  db = Room.databaseBuilder(this, AppDatabase::class.java, "noc.db").allowMainThreadQueries().fallbackToDestructiveMigration().build()

  if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED){
    ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS, Manifest.permission.POST_NOTIFICATIONS), 101)
  }

  val tabLayout = findViewById<TabLayout>(R.id.tabLayout)
  val recycler = findViewById<RecyclerView>(R.id.recycler)
  recycler.layoutManager = LinearLayoutManager(this)
  txAdapter = TxAdapter(emptyList())
  btsAdapter = BtsAdapter(emptyList())
  recycler.adapter = txAdapter
  loadTx()

  tabLayout.addOnTabSelectedListener(object: TabLayout.OnTabSelectedListener{
    override fun onTabSelected(tab: TabLayout.Tab?) {
      if (tab?.position == 0) loadTx() else loadBts()
    }
    override fun onTabUnselected(tab: TabLayout.Tab?) {}
    override fun onTabReselected(tab: TabLayout.Tab?) {}
  })

  findViewById<Button>(R.id.btnExport).setOnClickListener{ exportCsv() }
  findViewById<Button>(R.id.btnClear).setOnClickListener{ db.txDao().clear(); db.btsDao().clear(); loadTx(); Toast.makeText(this,"Cleared",Toast.LENGTH_SHORT).show() }

  registerReceiver(updateReceiver, IntentFilter("SMS_PARSED_UPDATE"))
 }

 val updateReceiver = object: BroadcastReceiver(){ override fun onReceive(c: Context?, i: Intent?){ loadTx(); loadBts() } }

 fun loadTx(){ val list = db.txDao().getAll(); txAdapter = TxAdapter(list); findViewById<RecyclerView>(R.id.recycler).adapter = txAdapter; findViewById<android.widget.TextView>(R.id.txtTitle).text = "TX NODES - ${'$'}{list.size} records" }
 fun loadBts(){ val list = db.btsDao().getAll(); btsAdapter = BtsAdapter(list); findViewById<RecyclerView>(R.id.recycler).adapter = btsAdapter; findViewById<android.widget.TextView>(R.id.txtTitle).text = "BTS NODES - ${'$'}{list.size} records" }

 fun exportCsv(){
   val tx = db.txDao().getAll()
   val bts = db.btsDao().getAll()
   val sb = StringBuilder()
   sb.appendLine("TX NODES")
   sb.appendLine("S.NO,NODE,TIME OF FAILURE,DOWN TIME,RESTORED,CPAN")
   tx.forEach{ sb.appendLine("${'$'}{it.sNo},${'$'}{it.node},${'$'}{it.failTime},${'$'}{it.downTime},${'$'}{it.restoredTime},${'$'}{it.cpan}") }
   sb.appendLine("")
   sb.appendLine("BTS NODES")
   sb.appendLine("S.NO,NODE,TIME OF FAILURE,SSA,TT ID,SEV,STATE")
   bts.forEach{ sb.appendLine("${'$'}{it.sNo},${'$'}{it.node},${'$'}{it.failTime},${'$'}{it.ssa},${'$'}{it.ttId},${'$'}{it.sev},${'$'}{it.state}") }
   // Save to Downloads
   val file = java.io.File(getExternalFilesDir(null), "bsnl_noc_export.csv")
   file.writeText(sb.toString())
   Toast.makeText(this, "Exported to ${'$'}{file.absolutePath}", Toast.LENGTH_LONG).show()
   val intent = Intent(Intent.ACTION_SEND).apply{ type="text/plain"; putExtra(Intent.EXTRA_TEXT, sb.toString()); }
   startActivity(Intent.createChooser(intent, "Share CSV"))
 }
 override fun onDestroy(){ super.onDestroy(); unregisterReceiver(updateReceiver) }
}
