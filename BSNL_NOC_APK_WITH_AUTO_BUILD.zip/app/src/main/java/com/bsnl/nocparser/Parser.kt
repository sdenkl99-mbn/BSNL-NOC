
package com.bsnl.nocparser

object Parser {
 data class TxData(val node: String, val failTime: String, val restoredTime: String, val downTime: String, val cpan: String, val fullSection: String)
 data class BtsData(val node: String, val ssa: String, val ttId: String, val createTm: String, val resTm: String, val sev: String, val state: String, val ip: String)

 fun parseTx(body: String): TxData? {
   try {
     val failRegex = Regex("Failed @ ([0-9-: ]+)", RegexOption.IGNORE_CASE)
     val restRegex = Regex("Restored @ ([0-9-: ]+)", RegexOption.IGNORE_CASE)
     val downRegex = Regex("Down Time ([0-9:]+)", RegexOption.IGNORE_CASE)
     val cpanRegex = Regex("(CPAN\\d+)", RegexOption.IGNORE_CASE)
     // Node is like TS_MBN_THUDUKURTHY_A1-1/5
     val nodeRegex = Regex("([A-Z]+_[A-Z]+_[A-Z0-9_]+-?[A-Z0-9/\\-_]+)\\s*Section", RegexOption.IGNORE_CASE)
     val nodes = nodeRegex.findAll(body).toList()
     val mainNode = nodes.lastOrNull()?.groupValues?.get(1) ?: ""
     // Simpler: extract THUDUKURTHY part
     val shortNode = Regex("THUDUKURTHY_[A-Z0-9-/_]+", RegexOption.IGNORE_CASE).find(body)?.value ?: mainNode

     val fail = failRegex.find(body)?.groupValues?.get(1) ?: ""
     val rest = restRegex.find(body)?.groupValues?.get(1) ?: ""
     val down = downRegex.find(body)?.groupValues?.get(1) ?: ""
     val cpan = cpanRegex.find(body)?.groupValues?.get(1) ?: ""
     val fullSec = Regex("in (.+?) Down Time", RegexOption.DOT_MATCHES_ALL).find(body)?.groupValues?.get(1)?.replace("\\n"," ") ?: body.take(100)
     if (fail.isEmpty() && down.isEmpty()) return null
     return TxData(node = shortNode, failTime = fail, restoredTime = rest, downTime = down, cpan = cpan, fullSection = fullSec)
   } catch(e: Exception){ return null }
 }

 fun parseBts(body: String): BtsData? {
  try {
   val ssaRegex = Regex("SSA:\\s*([^,\\n]+)", RegexOption.IGNORE_CASE)
   val nodeRegex = Regex("Node:\\s*([^,\\n]+)", RegexOption.IGNORE_CASE)
   val ttRegex = Regex("TT ID:\\s*([^,\\n]+)", RegexOption.IGNORE_CASE)
   val createRegex = Regex("Create_Tm:\\s*([^,]+,\\s*[0-9]+,\\s*[0-9]+\\s*[0-9:]+\\s*[AP]M)", RegexOption.IGNORE_CASE)
   val resRegex = Regex("Res_Tm:\\s*([^\\n]+)", RegexOption.IGNORE_CASE)
   val sevRegex = Regex("Sev:\\s*([^,\\n]+)", RegexOption.IGNORE_CASE)
   val stateRegex = Regex("State:\\s*([^,\\n]+)", RegexOption.IGNORE_CASE)
   val ipRegex = Regex("TT Desc:\\s*([0-9.]+)", RegexOption.IGNORE_CASE)

   val node = nodeRegex.find(body)?.groupValues?.get(1)?.trim() ?: ""
   if (!body.contains("SSA:") && !body.contains("Node:")) return null
   return BtsData(
     node = node,
     ssa = ssaRegex.find(body)?.groupValues?.get(1)?.trim() ?: "",
     ttId = ttRegex.find(body)?.groupValues?.get(1)?.trim() ?: "",
     createTm = createRegex.find(body)?.groupValues?.get(1)?.trim() ?: "",
     resTm = resRegex.find(body)?.groupValues?.get(1)?.trim() ?: "",
     sev = sevRegex.find(body)?.groupValues?.get(1)?.trim() ?: "",
     state = stateRegex.find(body)?.groupValues?.get(1)?.trim() ?: "",
     ip = ipRegex.find(body)?.groupValues?.get(1) ?: ""
   )
  } catch(e: Exception){ return null }
 }
}
