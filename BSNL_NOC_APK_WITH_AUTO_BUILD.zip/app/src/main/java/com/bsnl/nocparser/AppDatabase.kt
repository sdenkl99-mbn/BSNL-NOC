
package com.bsnl.nocparser
import androidx.room.*
@Dao interface TxDao { @Query("SELECT * FROM tx_nodes ORDER BY id DESC") fun getAll(): List<TxEntity>; @Insert fun insert(e:TxEntity); @Query("DELETE FROM tx_nodes") fun clear() }
@Dao interface BtsDao { @Query("SELECT * FROM bts_nodes ORDER BY id DESC") fun getAll(): List<BtsEntity>; @Insert fun insert(e:BtsEntity); @Query("DELETE FROM bts_nodes") fun clear() }
@Database(entities=[TxEntity::class, BtsEntity::class], version=1) abstract class AppDatabase: RoomDatabase(){ abstract fun txDao(): TxDao; abstract fun btsDao(): BtsDao }
