
package com.bsnl.nocparser
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="tx_nodes")
data class TxEntity(@PrimaryKey(autoGenerate=true) val id:Int=0, val sNo:Int, val node:String, val failTime:String, val restoredTime:String, val downTime:String, val cpan:String, val raw:String, val timestamp:Long=System.currentTimeMillis())

@Entity(tableName="bts_nodes")
data class BtsEntity(@PrimaryKey(autoGenerate=true) val id:Int=0, val sNo:Int, val node:String, val failTime:String, val ssa:String, val ttId:String, val sev:String, val state:String, val raw:String, val timestamp:Long=System.currentTimeMillis())
