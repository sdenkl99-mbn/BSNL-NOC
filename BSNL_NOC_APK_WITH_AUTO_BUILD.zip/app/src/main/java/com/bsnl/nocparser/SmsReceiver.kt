
package com.bsnl.nocparser
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import androidx.room.Room

class SmsReceiver: BroadcastReceiver(){
 override fun onReceive(context: Context, intent: Intent){
   if (Telephony.Sms.Intents.SMS_RECEIVED_ACTION != intent.action) return
   val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
   val db = Room.databaseBuilder(context, AppDatabase::class.java, "noc.db").allowMainThreadQueries().build()
   for (sms in messages){
     val body = sms.messageBody
     val sender = sms.originatingAddress ?: ""
     // Only parse our NOC senders
     if (sender.contains("BSZNMS") || sender.contains("OTNNOC") || sender.contains("BSNL") || body.contains("TS_MBN") || body.contains("SSA:")) {
       // TX Parse
       val tx = Parser.parseTx(body)
       if (tx != null){
         val count = db.txDao().getAll().size + 1
         db.txDao().insert(TxEntity(sNo=count, node=tx.node, failTime=tx.failTime, restoredTime=tx.restoredTime, downTime=tx.downTime, cpan=tx.cpan, raw=body))
       }
       val bts = Parser.parseBts(body)
       if (bts != null){
         val count = db.btsDao().getAll().size + 1
         db.btsDao().insert(BtsEntity(sNo=count, node=bts.node, failTime=bts.createTm, ssa=bts.ssa, ttId=bts.ttId, sev=bts.sev, state=bts.state, raw=body))
       }
     }
   }
   // Notify UI to refresh if open
   context.sendBroadcast(Intent("SMS_PARSED_UPDATE"))
 }
}
