
package com.bsnl.nocparser
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
class TxAdapter(val list:List<TxEntity>): RecyclerView.Adapter<TxAdapter.VH>(){
 class VH(v: View): RecyclerView.ViewHolder(v){ val tv = v.findViewById<TextView>(android.R.id.text1) }
 override fun onCreateViewHolder(p: ViewGroup, t:Int): VH { return VH(LayoutInflater.from(p.context).inflate(android.R.layout.simple_list_item_1, p, false)) }
 override fun getItemCount()=list.size
 override fun onBindViewHolder(h:VH, pos:Int){ val e=list[pos]; h.tv.text="${'$'}{e.sNo}. ${'$'}{e.node} | Fail:${'$'}{e.failTime} | Down:${'$'}{e.downTime} | ${'$'}{e.cpan}" }
}
class BtsAdapter(val list:List<BtsEntity>): RecyclerView.Adapter<BtsAdapter.VH>(){
 class VH(v: View): RecyclerView.ViewHolder(v){ val tv = v.findViewById<TextView>(android.R.id.text1) }
 override fun onCreateViewHolder(p: ViewGroup, t:Int): VH { return VH(LayoutInflater.from(p.context).inflate(android.R.layout.simple_list_item_1, p, false)) }
 override fun getItemCount()=list.size
 override fun onBindViewHolder(h:VH, pos:Int){ val e=list[pos]; h.tv.text="${'$'}{e.sNo}. ${'$'}{e.node} | ${'$'}{e.failTime} | ${'$'}{e.ssa} | ${'$'}{e.ttId}" }
}
